# Distrimax: funcionalidades sin cambios de estructura de BD

## Que se conserva
BD distrimax; tablas clientes, productos, pedidos y notificaciones originales.
Conexion localhost:3306, admin/admin solo para pruebas locales.
Configuracion src/main/resources/db.properties. Sin DDL ni migraciones incluidas.
No crea, renombra, elimina ni altera tablas al iniciar. Solo consulta e inserta/actualiza datos.
Si ya existen tablas v2, quedan intactas y NO se usan. Los datos exclusivos de esas
 tablas no se copian ni eliminan automaticamente. No borre esas tablas sin respaldo.

## Funcionalidades
- Bienvenida y descripcion al ingresar.
- Creacion de productos con nombre/precio desde la aplicacion.
- Seleccion de varios productos y cantidades, agregar/quitar y total previo.

## Limite importante de conservar el esquema
La tabla pedidos original solo admite UN producto por fila. Por ello una seleccion
con tres productos genera TRES pedidos independientes, en una unica transaccion.
Cada pedido tiene su ID, estado, factura y notificacion propios. No existe un numero
unico de pedido que agrupe todos los productos ni se simula ese agrupamiento.
Los productos repetidos se consolidan antes de guardar. Para un pedido unico con
varios detalles persistentes seria necesario un cambio de esquema, no incluido.

## Instalacion
1. Respalde su despliegue anterior y detenga Tomcat.
2. NO ejecute scripts SQL ni migraciones. Use sus tablas originales existentes.
3. Desde la carpeta de pom.xml: mvn clean package (JDK 17/21, Maven).
4. Reemplace WAR y carpeta expandida anteriores por target/distrimax-ventas.war.
5. Inicie Tomcat 10.1 y abra http://localhost:8080/distrimax-ventas/.
6. Ctrl+F5 para renovar archivos del navegador.
7. Cree un producto, seleccione dos productos y verifique los dos IDs generados.
8. Reinicie Tomcat y verifique persistencia en pedidos y notificaciones originales.

## Validacion y limites
Se comprobaron sintaxis JavaScript, XML POM y referencias a tablas originales.
No se ejecutaron Maven, Tomcat ni MySQL ni se valido integracion real en este entorno.
No incluye WAR precompilado. Correo/factura demo y pago manual, sin login de interfaz.
admin/admin es solo para entorno local; no exponer a internet.
