package com.distrimax.ventas.util;
import java.sql.*;
import java.util.Properties;
import java.io.InputStream;
public final class Database {
 private static final Properties P=new Properties();
 static {
  try(InputStream in=Database.class.getResourceAsStream("/db.properties")) {
   if(in==null) throw new IllegalStateException("Falta db.properties");
   P.load(in); Class.forName("com.mysql.cj.jdbc.Driver");
  } catch(Exception e) { throw new ExceptionInInitializerError(e); }
 }
 private Database(){}
 private static String value(String env,String key){String s=System.getenv(env); return s==null?P.getProperty(key):s;}
 public static Connection open() throws SQLException {
  return DriverManager.getConnection(value("DB_URL","db.url"),value("DB_USER","db.user"),value("DB_PASSWORD","db.password"));
 }
 public static void verificar(){
  try(Connection c=open(); Statement s=c.createStatement()) {
   for(String t:new String[]{"clientes","productos","pedidos","notificaciones"})
    try(ResultSet rs=s.executeQuery("SELECT 1 FROM "+t+" LIMIT 1")){}
  }catch(SQLException e){throw new IllegalStateException("No se pudo acceder a distrimax o faltan tablas. Ejecute sql/01_tablas_datos.sql y revise db.properties.",e);}
 }
}
