package com.distrimax.ventas.model;

import java.time.LocalDateTime;

public class Pedido {
    private final long id;
    private final Cliente cliente;
    private final Producto producto;
    private final int cantidad;
    private LocalDateTime fecha = LocalDateTime.now();
    private volatile EstadoPedido estado = EstadoPedido.REGISTRADO;
    private volatile String numeroFactura;
    private volatile String medioPago;

    public Pedido(long id, Cliente cliente, Producto producto, int cantidad) {
        this.id = id; this.cliente = cliente; this.producto = producto; this.cantidad = cantidad;
    }
    public long getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public java.math.BigDecimal getTotal() { return producto.getPrecio().multiply(java.math.BigDecimal.valueOf(cantidad)); }
    public void setFecha(LocalDateTime f) { this.fecha=f; }
    public LocalDateTime getFecha() { return fecha; }
    public EstadoPedido getEstado() { return estado; }
    public void setEstado(EstadoPedido e) { this.estado = e; }
    public String getNumeroFactura() { return numeroFactura; }
    public void setNumeroFactura(String n) { this.numeroFactura = n; }
    public String getMedioPago() { return medioPago; }
    public void setMedioPago(String m) { this.medioPago = m; }
}
