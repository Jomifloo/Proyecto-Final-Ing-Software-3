package com.distrimax.ventas.model;

/** Ciclo de venta: cada cambio de estado dispara un correo (RF-01). */
public enum EstadoPedido {
    REGISTRADO("Pedido de venta registrado"),
    DESPACHADO("Mercancía despachada"),
    FACTURADO("Factura emitida"),
    PAGADO("Pago registrado");

    private final String descripcion;
    EstadoPedido(String d) { this.descripcion = d; }
    public String getDescripcion() { return descripcion; }
}
