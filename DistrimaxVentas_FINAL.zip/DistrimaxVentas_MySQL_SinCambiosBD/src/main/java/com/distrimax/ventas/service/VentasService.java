package com.distrimax.ventas.service;
import com.distrimax.ventas.model.*;
import com.distrimax.ventas.util.Database;
import java.sql.*;
import java.util.*;
/** Persistencia JDBC: consultas preparadas y transacciones; sin mapas en memoria. */
public class VentasService {
 public static final Set<String> MEDIOS_PAGO=Set.of("Efectivo","Tarjeta débito","Tarjeta crédito","Transferencia","PSE");
 private final NotificacionService notificaciones;
 public VentasService(NotificacionService n){notificaciones=n; Database.verificar();}
 private static IllegalStateException error(SQLException e){return new IllegalStateException("Error de base de datos. Revise la consola de Tomcat.",e);}
 public Cliente crearCliente(String nombre,String documento,String correo){
  if(nombre==null||nombre.isBlank()||nombre.length()>100||documento==null||documento.isBlank()||documento.length()>25) throw new IllegalArgumentException("Nombre o documento no valido");
  if(correo==null||correo.length()>150||!correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) throw new IllegalArgumentException("Correo no valido");
  try(Connection c=Database.open(); PreparedStatement s=c.prepareStatement("INSERT INTO clientes(nombre,documento,correo) VALUES(?,?,?)",Statement.RETURN_GENERATED_KEYS)){
   s.setString(1,nombre.trim());s.setString(2,documento.trim());s.setString(3,correo.trim());s.executeUpdate();
   try(ResultSet k=s.getGeneratedKeys()){if(!k.next())throw new SQLException("Sin ID");return new Cliente(k.getLong(1),nombre.trim(),documento.trim(),correo.trim());}
  }catch(SQLIntegrityConstraintViolationException e){throw new IllegalArgumentException("El documento ya esta registrado");}catch(SQLException e){throw error(e);}
 }
 public List<Cliente> clientes(){
  List<Cliente> out=new ArrayList<>();
  try(Connection c=Database.open();PreparedStatement s=c.prepareStatement("SELECT id,nombre,documento,correo FROM clientes ORDER BY id");ResultSet rs=s.executeQuery()){
   while(rs.next())out.add(new Cliente(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4)));return out;
  }catch(SQLException e){throw error(e);}
 }
 public List<Producto> productos(){
  List<Producto> out=new ArrayList<>();
  try(Connection c=Database.open();PreparedStatement s=c.prepareStatement("SELECT id,nombre,precio FROM productos ORDER BY id");ResultSet rs=s.executeQuery()){
   while(rs.next())out.add(new Producto(rs.getLong(1),rs.getString(2),rs.getBigDecimal(3)));return out;
  }catch(SQLException e){throw error(e);}
 }
 public Producto crearProducto(String nombre,java.math.BigDecimal precio){
  if(nombre==null||nombre.isBlank()||nombre.length()>150)throw new IllegalArgumentException("Nombre requerido (maximo 150 caracteres)");
  if(precio==null||precio.signum()<=0||precio.scale()>2||precio.compareTo(new java.math.BigDecimal("999999999999.99"))>0)throw new IllegalArgumentException("Precio positivo, maximo 12 enteros y 2 decimales");
  try(Connection c=Database.open();PreparedStatement s=c.prepareStatement("INSERT INTO productos(nombre,precio) VALUES(?,?)",Statement.RETURN_GENERATED_KEYS)){
   s.setString(1,nombre.trim());s.setBigDecimal(2,precio);s.executeUpdate();try(ResultSet k=s.getGeneratedKeys()){if(!k.next())throw new SQLException("Sin ID");return new Producto(k.getLong(1),nombre.trim(),precio);}
  }catch(SQLException e){throw error(e);}
 }
 private static final String SELECT="SELECT p.*,c.nombre AS cliente_nombre,c.documento,c.correo,pr.nombre AS producto_nombre FROM pedidos p JOIN clientes c ON c.id=p.cliente_id JOIN productos pr ON pr.id=p.producto_id";
 private Pedido map(ResultSet rs)throws SQLException{
  Cliente c=new Cliente(rs.getLong("cliente_id"),rs.getString("cliente_nombre"),rs.getString("documento"),rs.getString("correo"));
  Producto pr=new Producto(rs.getLong("producto_id"),rs.getString("producto_nombre"),rs.getBigDecimal("precio_unitario"));
  Pedido p=new Pedido(rs.getLong("id"),c,pr,rs.getInt("cantidad"));p.setEstado(EstadoPedido.valueOf(rs.getString("estado")));p.setNumeroFactura(rs.getString("numero_factura"));p.setMedioPago(rs.getString("medio_pago"));p.setFecha(rs.getTimestamp("fecha_creacion").toLocalDateTime());return p;
 }
 private Pedido leer(Connection c,long id,boolean lock)throws SQLException{
  try(PreparedStatement s=c.prepareStatement(SELECT+" WHERE p.id=?"+(lock?" FOR UPDATE":""))){s.setLong(1,id);try(ResultSet rs=s.executeQuery()){return rs.next()?map(rs):null;}}
 }
 public Pedido pedido(long id){try(Connection c=Database.open()){return leer(c,id,false);}catch(SQLException e){throw error(e);}}
 public List<Pedido> pedidos(){
  List<Pedido> out=new ArrayList<>();
  try(Connection c=Database.open();PreparedStatement s=c.prepareStatement(SELECT+" ORDER BY p.id DESC LIMIT 500");ResultSet rs=s.executeQuery()){
   while(rs.next())out.add(map(rs));return out;
  }catch(SQLException e){throw error(e);}
 }
 public Pedido registrarPedido(long clienteId,long productoId,int cantidad){
  if(cantidad<1||cantidad>1000)throw new IllegalArgumentException("Cantidad entre 1 y 1000");
  try(Connection c=Database.open()){
   c.setAutoCommit(false);
   try{
    long id;
    try(PreparedStatement s=c.prepareStatement("INSERT INTO pedidos(cliente_id,producto_id,cantidad,precio_unitario) SELECT ?,id,?,precio FROM productos WHERE id=?",Statement.RETURN_GENERATED_KEYS)){
     s.setLong(1,clienteId);s.setInt(2,cantidad);s.setLong(3,productoId);
     if(s.executeUpdate()!=1)throw new IllegalArgumentException("Producto no existe");
     try(ResultSet k=s.getGeneratedKeys()){if(!k.next())throw new SQLException("Sin ID");id=k.getLong(1);}
    }
    Pedido p=leer(c,id,false);notificaciones.guardar(c,p);c.commit();return p;
   }catch(SQLException|RuntimeException e){c.rollback();throw e;}
  }catch(SQLIntegrityConstraintViolationException e){throw new IllegalArgumentException("Cliente o producto no valido");}catch(SQLException e){throw error(e);}
 }
 /** Sin cambiar esquema: cada producto se guarda como un pedido independiente.
  * La seleccion completa se confirma en una unica transaccion. */
 public List<Pedido> registrarSeleccion(long clienteId,Map<Long,Integer> items){
  if(items==null||items.isEmpty()||items.size()>100)throw new IllegalArgumentException("Seleccione de 1 a 100 productos");
  for(var e:items.entrySet())if(e.getKey()<1||e.getValue()<1||e.getValue()>1000)throw new IllegalArgumentException("Cantidad entre 1 y 1000");
  try(Connection c=Database.open()){
   c.setAutoCommit(false);
   try{
    List<Pedido> out=new ArrayList<>();
    for(var e:items.entrySet()){
     long id;
     try(PreparedStatement q=c.prepareStatement("INSERT INTO pedidos(cliente_id,producto_id,cantidad,precio_unitario) SELECT ?,id,?,precio FROM productos WHERE id=?",Statement.RETURN_GENERATED_KEYS)){
      q.setLong(1,clienteId);q.setInt(2,e.getValue());q.setLong(3,e.getKey());
      if(q.executeUpdate()!=1)throw new IllegalArgumentException("Producto no existe");
      try(ResultSet k=q.getGeneratedKeys()){if(!k.next())throw new SQLException("Sin ID");id=k.getLong(1);}
     }
     Pedido p=leer(c,id,false);notificaciones.guardar(c,p);out.add(p);
    }
    c.commit();return out;
   }catch(SQLException|RuntimeException e){c.rollback();throw e;}
  }catch(SQLIntegrityConstraintViolationException e){throw new IllegalArgumentException("Cliente o producto no valido");}catch(SQLException e){throw error(e);}
 }
 public Pedido despachar(long id){return avanzar(id,EstadoPedido.REGISTRADO,EstadoPedido.DESPACHADO,null);}
 public Pedido facturar(long id){return avanzar(id,EstadoPedido.DESPACHADO,EstadoPedido.FACTURADO,null);}
 public Pedido registrarPago(long id,String medio){if(!MEDIOS_PAGO.contains(Objects.toString(medio,"")))throw new IllegalArgumentException("Medio de pago no valido");return avanzar(id,EstadoPedido.FACTURADO,EstadoPedido.PAGADO,medio);}
 private Pedido avanzar(long id,EstadoPedido previo,EstadoPedido nuevo,String medio){
  try(Connection c=Database.open()){
   c.setAutoCommit(false);
   try{
    Pedido p=leer(c,id,true);
    if(p==null)throw new IllegalArgumentException("Pedido no existe");
    if(p.getEstado()!=previo)throw new IllegalStateException("Transicion no permitida desde "+p.getEstado());
    if(nuevo==EstadoPedido.FACTURADO)p.setNumeroFactura(String.format("DEMO-%08d",id));
    if(nuevo==EstadoPedido.PAGADO)p.setMedioPago(medio);
    p.setEstado(nuevo);
    try(PreparedStatement s=c.prepareStatement("UPDATE pedidos SET estado=?,numero_factura=?,medio_pago=? WHERE id=?")){
     s.setString(1,nuevo.name());s.setString(2,p.getNumeroFactura());s.setString(3,p.getMedioPago());s.setLong(4,id);s.executeUpdate();
    }
    notificaciones.guardar(c,p);c.commit();return p;
   }catch(SQLException|RuntimeException e){c.rollback();throw e;}
  }catch(SQLException e){throw error(e);}
 }
}
