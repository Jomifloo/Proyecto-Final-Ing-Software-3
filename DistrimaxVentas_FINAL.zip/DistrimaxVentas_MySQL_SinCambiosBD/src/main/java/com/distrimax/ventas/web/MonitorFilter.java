package com.distrimax.ventas.web;

import com.distrimax.ventas.service.MonitorService;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Registra cada petición a la API y si terminó en falla del servidor (RNF-03). */
@WebFilter("/api/*")
public class MonitorFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest r = (HttpServletRequest) req;
        r.getSession(true); // asegura sesión para el conteo de concurrencia
        MonitorService m = (MonitorService) r.getServletContext().getAttribute(AppListener.MONITOR);
        boolean fallo = false;
        try {
            chain.doFilter(req, res);
            fallo = ((HttpServletResponse) res).getStatus() >= 500;
        } catch (IOException | ServletException | RuntimeException ex) {
            fallo = true;
            throw ex;
        } finally {
            if (!r.getRequestURI().endsWith("/monitor")) m.peticion(fallo);
        }
    }
}
