package com.distrimax.ventas.model;

public class Cliente {
    private final long id;
    private final String nombre;
    private final String documento;
    private final String correo;

    public Cliente(long id, String nombre, String documento, String correo) {
        this.id = id; this.nombre = nombre; this.documento = documento; this.correo = correo;
    }
    public long getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDocumento() { return documento; }
    public String getCorreo() { return correo; }
}
