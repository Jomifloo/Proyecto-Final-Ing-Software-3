package com.distrimax.ventas.service;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Métricas para evidenciar RNF-01 (sesiones concurrentes) y
 * RNF-03 (tasa de falla <= 0,5 % del tiempo/operaciones).
 */
public class MonitorService {
    public static final int META_USUARIOS = 100_000;
    public static final double META_FALLA = 0.5; // %

    private final Instant inicio = Instant.now();
    private final AtomicInteger sesionesActivas = new AtomicInteger();
    private final AtomicInteger picoSesiones = new AtomicInteger();
    private final AtomicLong peticiones = new AtomicLong();
    private final AtomicLong fallas = new AtomicLong();

    public void sesionCreada() {
        int n = sesionesActivas.incrementAndGet();
        picoSesiones.accumulateAndGet(n, Math::max);
    }
    public void sesionDestruida() { sesionesActivas.updateAndGet(n -> Math.max(0, n - 1)); }
    public void peticion(boolean fallo) { peticiones.incrementAndGet(); if (fallo) fallas.incrementAndGet(); }

    public int getSesionesActivas() { return sesionesActivas.get(); }
    public int getPicoSesiones() { return picoSesiones.get(); }
    public long getPeticiones() { return peticiones.get(); }
    public long getFallas() { return fallas.get(); }
    public double getTasaFalla() {
        long t = peticiones.get();
        return t == 0 ? 0 : (fallas.get() * 100.0) / t;
    }
    public double getDisponibilidad() { return 100.0 - getTasaFalla(); }
    public boolean cumpleRnf03() { return getTasaFalla() <= META_FALLA; }
    public long getSegundosActivo() { return Duration.between(inicio, Instant.now()).getSeconds(); }
}
