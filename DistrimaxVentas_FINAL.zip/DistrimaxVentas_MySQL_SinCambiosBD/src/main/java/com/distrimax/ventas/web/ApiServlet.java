package com.distrimax.ventas.web;

import com.distrimax.ventas.model.Pedido;
import com.distrimax.ventas.service.MonitorService;
import com.distrimax.ventas.service.NotificacionService;
import com.distrimax.ventas.service.VentasService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Map;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * API REST:
 *  GET  /api/productos | /api/clientes | /api/pedidos | /api/pedidos/{id} | /api/correos | /api/monitor
 *  POST /api/clientes  {nombre,documento,correo}
 *  POST /api/pedidos   {clienteId,productoId,cantidad}
 *  POST /api/pedidos/{id}/despachar | /facturar | /pagar {medioPago}
 */
@WebServlet("/api/*")
public class ApiServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(ApiServlet.class.getName());

    private VentasService ventas() { return (VentasService) getServletContext().getAttribute(AppListener.VENTAS); }
    private NotificacionService notif() { return (NotificacionService) getServletContext().getAttribute(AppListener.NOTIF); }
    private MonitorService monitor() { return (MonitorService) getServletContext().getAttribute(AppListener.MONITOR); }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        manejar(res, () -> {
            String[] p = partes(req);
            switch (p[0]) {
                case "productos": return Json.arr(ventas().productos(), Json::producto);
                case "clientes":  return Json.arr(ventas().clientes(), Json::cliente);
                case "correos":   return Json.arr(notif().bandeja(), Json::correo);
                case "mediosPago": return Json.arr(new TreeSet<>(VentasService.MEDIOS_PAGO), Json::str);
                case "monitor":   return monitorJson();
                case "pedidos":
                    if (p.length == 1) return Json.arr(ventas().pedidos(), Json::pedido);
                    Pedido ped = ventas().pedido(Long.parseLong(p[1]));
                    if (ped == null) throw new NoEncontrado("Pedido no encontrado");
                    return Json.pedido(ped);
                default: throw new NoEncontrado("Recurso no encontrado");
            }
        });
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        manejar(res, () -> {
            String[] p = partes(req);
            Map<String, String> b = Json.parse(new String(req.getInputStream().readAllBytes(), "UTF-8"));
            if (p[0].equals("productos") && p.length == 1) {
                java.math.BigDecimal precio;
                try {precio=new java.math.BigDecimal(b.get("precio"));}catch(RuntimeException ex){throw new IllegalArgumentException("Precio no valido");}
                String out=Json.producto(ventas().crearProducto(b.get("nombre"),precio));res.setStatus(201);return out;
            }
            if (p[0].equals("clientes") && p.length == 1) {
                res.setStatus(201);
                return Json.cliente(ventas().crearCliente(b.get("nombre"), b.get("documento"), b.get("correo")));
            }
            if (p[0].equals("pedidos")) {
                if (p.length == 1) {
                    res.setStatus(201);
                    return Json.arr(ventas().registrarSeleccion(num(b, "clienteId"), Json.lineas(b.get("items"))), Json::pedido);
                }
                long id = Long.parseLong(p[1]);
                String accion = p.length > 2 ? p[2] : "";
                switch (accion) {
                    case "despachar": return Json.pedido(ventas().despachar(id));
                    case "facturar":  return Json.pedido(ventas().facturar(id));
                    case "pagar":     return Json.pedido(ventas().registrarPago(id, b.get("medioPago")));
                    default: break;
                }
            }
            throw new NoEncontrado("Recurso no encontrado");
        });
    }

    private String monitorJson() {
        MonitorService m = monitor();
        return String.format(java.util.Locale.US,
            "{\"sesionesActivas\":%d,\"picoSesiones\":%d,\"metaUsuarios\":%d,\"peticiones\":%d,\"fallas\":%d,"
            + "\"tasaFalla\":%.3f,\"metaFalla\":%.1f,\"disponibilidad\":%.3f,\"cumpleRnf03\":%b,\"segundosActivo\":%d}",
            m.getSesionesActivas(), m.getPicoSesiones(), MonitorService.META_USUARIOS, m.getPeticiones(),
            m.getFallas(), m.getTasaFalla(), MonitorService.META_FALLA, m.getDisponibilidad(),
            m.cumpleRnf03(), m.getSegundosActivo());
    }

    // ---------- utilidades ----------
    private interface Accion { String run() throws Exception; }
    private static class NoEncontrado extends RuntimeException { NoEncontrado(String m) { super(m); } }

    private void manejar(HttpServletResponse res, Accion a) throws IOException {
        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Cache-Control", "no-store");
        String out;
        try {
            out = a.run();
        } catch (NoEncontrado e) {
            res.setStatus(404); out = error(e.getMessage());
        } catch (IllegalArgumentException e) {   // incluye NumberFormatException
            res.setStatus(400); out = error(e.getMessage());
        } catch (IllegalStateException e) {
            if(e.getCause() instanceof java.sql.SQLException){ LOG.log(Level.SEVERE,"Error SQL",e); res.setStatus(500); out=error("No fue posible acceder a la base de datos"); }
            else {res.setStatus(409); out = error(e.getMessage());}
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Error interno", e);
            res.setStatus(500); out = error("Error interno del servidor");
        }
        res.getWriter().write(out);
    }

    private static String error(String m) { return "{\"error\":" + Json.str(m) + "}"; }

    private static String[] partes(HttpServletRequest req) {
        String path = req.getPathInfo();
        if (path == null || path.equals("/")) return new String[]{""};
        return path.substring(1).split("/");
    }

    private static long num(Map<String, String> b, String k) {
        String v = b.get(k);
        if (v == null) throw new IllegalArgumentException("Falta el campo " + k);
        try { return Long.parseLong(v); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("Valor no válido para " + k); }
    }
}
