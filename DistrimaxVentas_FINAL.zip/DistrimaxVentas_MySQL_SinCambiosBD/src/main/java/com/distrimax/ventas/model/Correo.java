package com.distrimax.ventas.model;

import java.time.LocalDateTime;

public class Correo {
    private final String para;
    private final String asunto;
    private final String cuerpo;
    private LocalDateTime fecha = LocalDateTime.now();

    public Correo(String para, String asunto, String cuerpo) {
        this.para = para; this.asunto = asunto; this.cuerpo = cuerpo;
    }
    public String getPara() { return para; }
    public String getAsunto() { return asunto; }
    public String getCuerpo() { return cuerpo; }
    public void setFecha(LocalDateTime f) { fecha=f; }
    public LocalDateTime getFecha() { return fecha; }
}
