package com.distrimax.ventas.service;
import com.distrimax.ventas.model.*;
import com.distrimax.ventas.util.Database;
import java.sql.*;
import java.util.*;
/** Notificaciones DEMO persistentes, guardadas en la misma transaccion que la venta. No envia SMTP. */
public class NotificacionService {
 public void guardar(Connection c,Pedido p) throws SQLException {
  String asunto="Distrimax - "+p.getEstado().getDescripcion()+" (Pedido #"+p.getId()+")";
  String cuerpo="Hola "+p.getCliente().getNombre()+",\nPedido #"+p.getId()+": "+p.getEstado().getDescripcion()+
   "\nProducto: "+p.getProducto().getNombre()+" x"+p.getCantidad()+"\nTotal: "+p.getTotal().toPlainString()+" COP"+
   "\nFactura demo: "+Objects.toString(p.getNumeroFactura(),"Pendiente")+"\nMedio: "+Objects.toString(p.getMedioPago(),"Pendiente");
  try(PreparedStatement s=c.prepareStatement("INSERT INTO notificaciones(pedido_id,evento,destinatario,asunto,cuerpo,estado) VALUES(?,?,?,?,?,'SIMULADO')")){
   s.setLong(1,p.getId()); s.setString(2,p.getEstado().name()); s.setString(3,p.getCliente().getCorreo()); s.setString(4,asunto); s.setString(5,cuerpo); s.executeUpdate();
  }
 }
 public List<Correo> bandeja(){
  List<Correo> out=new ArrayList<>();
  try(Connection c=Database.open(); PreparedStatement s=c.prepareStatement("SELECT destinatario,asunto,cuerpo,fecha_creacion FROM notificaciones ORDER BY id DESC LIMIT 200"); ResultSet rs=s.executeQuery()){
   while(rs.next()){Correo x=new Correo(rs.getString(1),rs.getString(2),rs.getString(3)); x.setFecha(rs.getTimestamp(4).toLocalDateTime()); out.add(x);}
   return out;
  }catch(SQLException e){throw new IllegalStateException("No fue posible consultar notificaciones",e);}
 }
 public void cerrar(){}
}
