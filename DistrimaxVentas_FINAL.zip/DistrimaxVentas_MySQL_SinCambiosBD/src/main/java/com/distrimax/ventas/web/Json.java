package com.distrimax.ventas.web;
import com.distrimax.ventas.model.*;
import com.google.gson.*;
import java.util.*;
import java.util.function.Function;
final class Json {
 private static final Gson G=new Gson();
 static String str(String s){return G.toJson(s);}
 static <T> String arr(Collection<T> items,Function<T,String> f){return items.stream().map(f).collect(java.util.stream.Collectors.joining(",","[","]"));}
 static String cliente(Cliente c){return G.toJson(Map.of("id",c.getId(),"nombre",c.getNombre(),"documento",c.getDocumento(),"correo",c.getCorreo()));}
 static String producto(Producto p){return G.toJson(Map.of("id",p.getId(),"nombre",p.getNombre(),"precio",p.getPrecio()));}
 static String pedido(Pedido p){
  Map<String,Object> m=new LinkedHashMap<>();m.put("id",p.getId());m.put("cliente",JsonParser.parseString(cliente(p.getCliente())));m.put("total",p.getTotal());m.put("fecha",p.getFecha().toString());m.put("estado",p.getEstado().name());m.put("estadoDescripcion",p.getEstado().getDescripcion());m.put("factura",p.getNumeroFactura());m.put("medioPago",p.getMedioPago());
  m.put("detalles",List.of(Map.of("productoId",p.getProducto().getId(),"nombre",p.getProducto().getNombre(),"cantidad",p.getCantidad(),"precioUnitario",p.getProducto().getPrecio(),"subtotal",p.getTotal())));return G.toJson(m);
 }
 static String correo(Correo c){return G.toJson(Map.of("para",c.getPara(),"asunto",c.getAsunto(),"cuerpo",c.getCuerpo(),"fecha",c.getFecha().toString()));}
 static Map<String,String> parse(String body){
  try{
   JsonObject obj=JsonParser.parseString(body).getAsJsonObject();Map<String,String> out=new HashMap<>();
   for(var e:obj.entrySet())if(!e.getValue().isJsonNull())out.put(e.getKey(),e.getValue().isJsonPrimitive()?e.getValue().getAsString():e.getValue().toString());return out;
  }catch(RuntimeException e){throw new IllegalArgumentException("JSON no valido");}
 }
 static Map<Long,Integer> lineas(String json){
  try{
   JsonArray a=JsonParser.parseString(json).getAsJsonArray();if(a.size()<1||a.size()>100)throw new IllegalArgumentException();
   Map<Long,Integer> out=new TreeMap<>();
   for(JsonElement el:a){JsonObject o=el.getAsJsonObject();long id=new java.math.BigDecimal(o.get("productoId").getAsString()).longValueExact();int n=new java.math.BigDecimal(o.get("cantidad").getAsString()).intValueExact();
    if(id<1||n<1||n>1000)throw new IllegalArgumentException();int total=Math.addExact(out.getOrDefault(id,0),n);if(total>1000)throw new IllegalArgumentException();out.put(id,total);
   }return out;
  }catch(RuntimeException e){throw new IllegalArgumentException("Items no validos: 1 a 100 productos, cantidades enteras entre 1 y 1000");}
 }
}
