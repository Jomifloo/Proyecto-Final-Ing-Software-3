package com.distrimax.ventas.model;

public class Producto {
    private final long id;
    private final String nombre;
    private final java.math.BigDecimal precio;

    public Producto(long id, String nombre, java.math.BigDecimal precio) {
        this.id = id; this.nombre = nombre; this.precio = precio;
    }
    public long getId() { return id; }
    public String getNombre() { return nombre; }
    public java.math.BigDecimal getPrecio() { return precio; }
}
