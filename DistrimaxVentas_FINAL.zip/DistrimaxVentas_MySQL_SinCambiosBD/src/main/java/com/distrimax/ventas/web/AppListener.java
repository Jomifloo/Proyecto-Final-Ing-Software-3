package com.distrimax.ventas.web;

import com.distrimax.ventas.service.MonitorService;
import com.distrimax.ventas.service.NotificacionService;
import com.distrimax.ventas.service.VentasService;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;

/** Inicializa los servicios y cuenta sesiones concurrentes (RNF-01). */
@WebListener
public class AppListener implements ServletContextListener, HttpSessionListener {
    static final String VENTAS = "ventas", NOTIF = "notif", MONITOR = "monitor";

    @Override public void contextInitialized(ServletContextEvent e) {
        NotificacionService n = new NotificacionService();
        e.getServletContext().setAttribute(NOTIF, n);
        e.getServletContext().setAttribute(VENTAS, new VentasService(n));
        e.getServletContext().setAttribute(MONITOR, new MonitorService());
    }
    @Override public void contextDestroyed(ServletContextEvent e) {
        Object n=e.getServletContext().getAttribute(NOTIF);
        if(n instanceof NotificacionService) ((NotificacionService)n).cerrar();
    }
    @Override public void sessionCreated(HttpSessionEvent se) {
        ((MonitorService) se.getSession().getServletContext().getAttribute(MONITOR)).sesionCreada();
    }
    @Override public void sessionDestroyed(HttpSessionEvent se) {
        ((MonitorService) se.getSession().getServletContext().getAttribute(MONITOR)).sesionDestruida();
    }
}
